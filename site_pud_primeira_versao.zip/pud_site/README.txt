PUD - Liga de Direito Empresarial da PUC-Rio

1. Abra index.html no navegador para visualizar a primeira versão do site.
2. A página admin.html é uma área reservada ilustrativa e NÃO contém login real.
3. Para publicar e permitir edição por login exclusivo, implemente autenticação no servidor (ex.: Supabase Auth), banco de dados e regras de autorização. Nunca armazene senhas no JavaScript.
4. Os eventos e notícias desta versão estão no objeto defaults no fim de index.html. São conteúdo de demonstração e podem ser editados no código.
5. Confirme nomes, datas, logotipo e contatos antes da publicação.
6. Hospedagem possível: Netlify, Vercel ou GitHub Pages (apenas a parte pública estática).
